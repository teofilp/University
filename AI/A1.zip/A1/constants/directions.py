#define directions
UP = 0
DOWN = 2
LEFT = 1
RIGHT = 3